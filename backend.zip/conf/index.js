const mongoose = require('mongoose');
mongoose.connect(
  'mongodb+srv://RajaSabiq:Joker170@cluster0.ntvkl02.mongodb.net/demo?retryWrites=true&w=majority'
);
