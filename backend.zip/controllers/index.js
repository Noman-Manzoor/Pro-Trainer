const { createStudent, sendVerifyCode, verifyCode } = require('./students');

module.exports = { createStudent, sendVerifyCode, verifyCode };
