const {
  createStudent,
  sendVerifyCode,
  verifyCode,
  getCategory,
  addCategory,
} = require('./students');

module.exports = {
  createStudent,
  sendVerifyCode,
  verifyCode,
  getCategory,
  addCategory,
};
