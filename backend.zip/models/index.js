const students = require('./students');
const verification = require('./verification');

module.exports = {
  students,
  verification,
};
