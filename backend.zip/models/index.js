const students = require('./students');
const verification = require('./verification');
const category = require('./verification');

module.exports = {
  students,
  verification,
  category,
};
